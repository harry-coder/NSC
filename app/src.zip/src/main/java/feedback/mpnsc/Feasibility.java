package feedback.mpnsc;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by swatiG on 29-06-2015.
 */
public class Feasibility extends Activity {

    TextView tv_lat_home,tv_long_home, tv_lat_pole, tv_long_pole, tv_feasibility;
    Button btn_home_nw, btn_home_gps, btn_pole_nw, btn_pole_gps,btn_feasibility,submit ;
    Spinner spinner_ds,spinner_ndsb;
    String str_spinner_ds,str_spinner_ndsb;


    AppLocationService appLocationService;
    double home_lat,home_long, pole_lat, pole_long;
    RadioGroup radio_consumer_type,radio_wiring_status,radio_tariff_type;
    RadioButton radio_wiring_yes, radio_wiring_no;

    SessionManager sessionManager;
    String response,network_interrupt,value_feasibility,str_ticket_no;

    SQLiteMasterTableAdapter sqLiteMasterTableAdapter;

    ConnectionDetector connectionDetector;

    EditText edt_manual_fes;
    EditText tranformer_capacity,tranformer_code,pole_no,mru_no,n_cons_no,n_mru_no;
    String str_tranformer_capacity,str_tranformer_code,str_pole_no,str_mru_no,str_n_cons_no,str_n_mru_no,tariff_ds,tariff_ndsa,tariff_ndsb;
    String str_manual_fes;
    String value_levied,value_wiring,value_tariff;
    LinearLayout linear_distance;

    SQLiteAdapter sqLiteAdapter;
    ArrayList routeArraycode;
    ArrayAdapter<String> routeAdapter;
    Spinner route_spinner;
    String str_route;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feasibility);
        callView();
        appLocationService = new AppLocationService(
                Feasibility.this);
        sessionManager=new SessionManager(Feasibility.this);
        sqLiteMasterTableAdapter=new SQLiteMasterTableAdapter(Feasibility.this);
        connectionDetector=new ConnectionDetector(Feasibility.this);
        linear_distance=(LinearLayout)findViewById(R.id.linear_distance);
        //route_spinner=(Spinner)findViewById(R.id.route_spinner);
        tariff_ds = spinner_ds.getSelectedItem().toString();
        tariff_ndsa = spinner_ndsb.getSelectedItem().toString();

        linear_distance.setVisibility(View.INVISIBLE);
       /* spinner_ndsb.setVisibility(View.GONE);
        spinner_ds.setVisibility(View.GONE);
      */
        sqLiteAdapter=new SQLiteAdapter(Feasibility.this);
        routeArraycode=new ArrayList<String>();

        //new RouteNo().execute();

        str_ticket_no=getIntent().getStringExtra("ticket");
        btn_home_nw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getHomeLocationNetwork();
            }
        });

        btn_home_gps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getHomeLocationGPS();
            }
        });

        btn_pole_nw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getPoleLocationNetwork();
            }
        });


        btn_pole_gps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getPoleLocationGPS();
            }
        });


        radio_tariff_type = (RadioGroup) findViewById(R.id.radio_tariff_type);
        radio_tariff_type.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {

                if (checkedId == R.id.radio_ds_yes) {
                    value_tariff = "1000";

                    spinner_ds.setVisibility(View.VISIBLE);
                    spinner_ndsb.setVisibility(View.INVISIBLE);
                   /* tariff_ds = spinner_ds.getSelectedItem().toString();
                    Toast.makeText(getApplicationContext(),": \nTariff: " + value_tariff + "\n Load: " + tariff_ds,Toast.LENGTH_LONG).show();
                    DataHolderClass.getInstance().setFeasibility_tariff_load(tariff_ds);*/
                    //spinner_ndsb.setVisibility(View.INVISIBLE);
                    DataHolderClass.getInstance().set_connect_load(value_tariff);

                } else if (checkedId == R.id.radio_ndsa_no) {
                    value_tariff = "2000";

                   /* tariff_ndsa = spinner_ndsb.getSelectedItem().toString();
                    DataHolderClass.getInstance().setFeasibility_tariff_load(tariff_ndsa);*/
                    spinner_ndsb.setVisibility(View.VISIBLE);

                   // Toast.makeText(getApplicationContext(),": \nTariff: " + value_tariff + "\n Load: " + tariff_ndsa,Toast.LENGTH_LONG).show();

                    spinner_ds.setVisibility(View.INVISIBLE);

                    DataHolderClass.getInstance().set_connect_load(value_tariff);
                }else if (checkedId == R.id.radio_ndsb_no) {
                    value_tariff = "3000";
                    spinner_ds.setVisibility(View.VISIBLE);
                    spinner_ndsb.setVisibility(View.INVISIBLE);
/*
                    tariff_ds = spinner_ds.getSelectedItem().toString();
                    Toast.makeText(getApplicationContext(),": \nTariff: " + value_tariff + "\n Load: " + tariff_ds,Toast.LENGTH_LONG).show();
                     DataHolderClass.getInstance().setFeasibility_tariff_load(tariff_ds);*/
                    DataHolderClass.getInstance().set_connect_load(value_tariff);
                }

            }
        });

        radio_consumer_type = (RadioGroup) findViewById(R.id.radio_consumer_type);
        radio_consumer_type.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {

                if (checkedId == R.id.radio_con_yes) {
                    value_levied = "0";
                    n_cons_no.setVisibility(View.VISIBLE);
                    n_mru_no.setVisibility(View.VISIBLE);
                    DataHolderClass.getInstance().setRadio_adjacent_cons(value_levied);

                } else if (checkedId == R.id.radio_con_no) {
                    value_levied = "1";
                    n_cons_no.setVisibility(View.VISIBLE);
                    n_mru_no.setVisibility(View.VISIBLE);

                    DataHolderClass.getInstance().setRadio_adjacent_cons(value_levied);
                }

            }
        });


        radio_wiring_status = (RadioGroup) findViewById(R.id.radio_wiring_type);
        radio_wiring_status.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {

                if (checkedId == R.id.radio_wiring_yes) {
                    value_wiring = "0";
                    DataHolderClass.getInstance().setRadio_wiring_status(value_wiring);

                } else if (checkedId == R.id.radio_wiring_no) {
                    value_wiring = "1";
                    DataHolderClass.getInstance().setRadio_wiring_status(value_wiring);
                }

            }
        });


        btn_feasibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                home_lat= Double.parseDouble(tv_lat_home.getText().toString().trim()) ;
                home_long= Double.parseDouble(tv_long_home.getText().toString().trim()) ;

                pole_lat= Double.parseDouble(tv_lat_pole.getText().toString().trim()) ;
                pole_long= Double.parseDouble(tv_long_pole.getText().toString().trim()) ;

                if(home_lat==0.0|| home_long== 0.0 || pole_lat== 0.0 ||pole_long ==0.0)
                {
                    Log.e("from","if");
                    Toast.makeText(getApplicationContext(),"get all location", Toast.LENGTH_SHORT).show();
                    //btn_feasibility.setClickable(false);

                }
                else {
                    //btn_feasibility.setClickable(true);
                    float[] result=new float[5];
                    Log.e("from","else");
                    Location.distanceBetween(home_lat,home_long,pole_lat,pole_long,result);
                    // Location.distanceBetween(28.4940004,77.0949538,28.4939842,77.0949632,result);

                    String d= Float.toString(result[0]);
                    tv_feasibility.setText(d);
                    value_feasibility=tv_feasibility.getText().toString().trim();
                    linear_distance.setVisibility(View.VISIBLE);
                    submit.setVisibility(View.VISIBLE);
                    // edt_manual_fes.setVisibility(View.VISIBLE);
                    submit.setClickable(true);
                    //   Toast.makeText(Feasibility.this, "Distance is " + d,Toast.LENGTH_SHORT).show();
                }
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                str_manual_fes=edt_manual_fes.getText().toString().trim();
                str_tranformer_capacity = tranformer_capacity.getText().toString().trim();
                str_tranformer_code = tranformer_code.getText().toString().trim();
                str_pole_no = pole_no.getText().toString().trim();
                str_n_cons_no = n_cons_no.getText().toString().trim();
                str_n_mru_no = n_mru_no.getText().toString().trim();

                tariff_ds = spinner_ds.getSelectedItem().toString();
               /* Toast.makeText(getApplicationContext(),": \nTariff: " + value_tariff + "\n Load: " + tariff_ds,Toast.LENGTH_LONG).show();
                DataHolderClass.getInstance().setFeasibility_tariff_load(tariff_ds);*/

                tariff_ndsa = spinner_ndsb.getSelectedItem().toString();
               /* Toast.makeText(getApplicationContext(),": \nTariff: " + value_tariff + "\n Load: " + tariff_ndsa,Toast.LENGTH_LONG).show();
                DataHolderClass.getInstance().setFeasibility_tariff_load_b(tariff_ndsa);*/

                Pattern p = Pattern.compile("[0-9]*\\.?[0-9]+");
                Matcher m = p.matcher(tariff_ds+""+tariff_ndsa);
                while (m.find()) {
                   /* System.out.println(m.group());
                    Log.e("from1234",m.group());*/
                    DataHolderClass.getInstance().setFeasibility_tariff_load(m.group());
                }

               /* tariff_ds = spinner_ds.getSelectedItem().toString();
                DataHolderClass.getInstance().setFeasibility_tariff_load(tariff_ds);

                tariff_ndsa = spinner_ndsb.getSelectedItem().toString();
                DataHolderClass.getInstance().setFeasibility_tariff_load(tariff_ndsa);*/
                //DataHolderClass.getInstance().setFeasibility_tariff_load_b(tariff_ndsa);

                DataHolderClass.getInstance().setTicket_no(str_ticket_no);
                DataHolderClass.getInstance().setHome_lat(String.valueOf(home_lat));
                DataHolderClass.getInstance().setHome_long(String.valueOf(home_long));
                DataHolderClass.getInstance().setPole_lat(String.valueOf(pole_lat));
                DataHolderClass.getInstance().setPole_long(String.valueOf(pole_long));
                DataHolderClass.getInstance().setValue_feasibility(value_feasibility);
                DataHolderClass.getInstance().setStr_manual_fes(str_manual_fes);
                DataHolderClass.getInstance().setStr_transformer_capacity(str_tranformer_capacity);
                DataHolderClass.getInstance().setStr_transformer_code(str_tranformer_code);
                DataHolderClass.getInstance().setPole_number(str_pole_no);
                DataHolderClass.getInstance().setMru_number(str_mru_no);
                DataHolderClass.getInstance().setAdjacent_cons_no(str_n_cons_no);
                DataHolderClass.getInstance().setAdjacent_mru_no(str_n_mru_no);

                str_manual_fes=edt_manual_fes.getText().toString().trim();

                if(TextUtils.isEmpty(str_tranformer_capacity)){
                    Toast.makeText(getApplicationContext(), "Enter Tranformer Capacity* ", Toast.LENGTH_SHORT).show();

                } else if(TextUtils.isEmpty(str_tranformer_code)){
                    Toast.makeText(getApplicationContext(), "Enter Tranformer Code* ", Toast.LENGTH_SHORT).show();

                }
                else if(TextUtils.isEmpty(str_pole_no)){
                    Toast.makeText(getApplicationContext(), "Enter Pole Number* ", Toast.LENGTH_SHORT).show();

                } else if (radio_tariff_type.getCheckedRadioButtonId() == -1)
                {
                    Toast.makeText(getApplicationContext(),"Select Tariff Category radio button",Toast.LENGTH_SHORT).show();
                    // hurray at-least on radio button is checked.
                }else  if(spinner_ds.getSelectedItem().toString().trim().equals("select")&& spinner_ndsb.getSelectedItem().toString().trim().equals("select")){
                    Toast.makeText(getApplicationContext(), "Select Category Load Required", Toast.LENGTH_SHORT).show();

                }else if (radio_consumer_type.getCheckedRadioButtonId() == -1)
                {
                    Toast.makeText(getApplicationContext(),"Select Previous connection in same premises radio button",Toast.LENGTH_SHORT).show();

                } else if(TextUtils.isEmpty(str_n_cons_no)){
                    Toast.makeText(getApplicationContext(), "Enter Adj Consumer Number* ", Toast.LENGTH_SHORT).show();

                }else if(TextUtils.isEmpty(str_n_mru_no)){
                    Toast.makeText(getApplicationContext(), "Enter Adj MRU Number* ", Toast.LENGTH_SHORT).show();

                }else if (radio_wiring_status.getCheckedRadioButtonId() == -1)
                {
                    Toast.makeText(getApplicationContext(),"Select Wiring Status radio button",Toast.LENGTH_SHORT).show();

                } else if(TextUtils.isEmpty(str_manual_fes)){
                    Toast.makeText(getApplicationContext(), "Enter Distance* ", Toast.LENGTH_SHORT).show();

                }/*else if(Integer.parseInt(str_manual_fes)>31){
                    Toast.makeText(getApplicationContext(), "Distance Not More than 30 meter* ", Toast.LENGTH_SHORT).show();

                }*/

                else {
                   /* if (connectionDetector.isConnectingToInternet()) {
                         new SendFeasibility().execute();
                    } else {
                        sqLiteMasterTableAdapter.openToRead();
                        sqLiteMasterTableAdapter.openToWrite();
                        sqLiteMasterTableAdapter.insert_feasibility("set_feasibility", "str_ticket_no",
                                String.valueOf(home_lat),
                                String.valueOf(home_long),
                                String.valueOf(pole_lat),
                                String.valueOf(pole_long),
                                str_route,
                                value_feasibility, str_manual_fes
                        );
                        sqLiteMasterTableAdapter.close();
                        Toast.makeText(getApplicationContext(), "Record Saved ", Toast.LENGTH_SHORT).show();
                        finish();

                    }*/

                   startActivity(new Intent(Feasibility.this, Feasibility_photo.class));
                    finish();
                }
            }
        });



    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        ShowAlertonBack();
    }
    public void ShowAlertonBack(){
        Feasibility.this.runOnUiThread(new Runnable() {
            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(Feasibility.this);
                builder.setCancelable(false);
                builder.setTitle("Are you sure to go back:");
                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        startActivity(new Intent(Feasibility.this, SearchTicket_Feasibility.class));
                        finish();

                    }
                });
                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
    }


    public void callView()
    {

        radio_wiring_yes = (RadioButton) findViewById(R.id.radio_wiring_yes);

        radio_wiring_no = (RadioButton) findViewById(R.id.radio_wiring_no);


        tv_lat_home=(TextView)findViewById(R.id.tv_lat_home);
        tv_long_home=(TextView)findViewById(R.id.tv_long_home);
        tv_lat_pole=(TextView)findViewById(R.id.tv_lat_pole);
        tv_long_pole=(TextView)findViewById(R.id.tv_long_pole);
        tv_feasibility=(TextView)findViewById(R.id.tv_feasibility);

        spinner_ds=(Spinner)findViewById(R.id.spinner_load_ds);
        spinner_ds.setVisibility(View.GONE);
        spinner_ndsb=(Spinner)findViewById(R.id.spinner_load_ndsa);
        spinner_ndsb.setVisibility(View.GONE);


        tranformer_capacity=(EditText)findViewById(R.id.tranformer_capacity);
        tranformer_code=(EditText)findViewById(R.id.tranformer_code);
        pole_no=(EditText)findViewById(R.id.pole_no);
        //mru_no=(EditText)findViewById(R.id.mru_no);

        n_cons_no=(EditText)findViewById(R.id.et_ncons_no);
        n_cons_no.setVisibility(View.GONE);
        n_mru_no=(EditText)findViewById(R.id.et_nmru_no);
        n_mru_no.setVisibility(View.GONE);

        btn_home_nw=(Button)findViewById(R.id.home_network);
        btn_home_gps=(Button)findViewById(R.id.home_gps);
        btn_pole_nw=(Button)findViewById(R.id.pole_network);
        btn_pole_gps=(Button)findViewById(R.id.pole_gps);
        btn_feasibility=(Button)findViewById(R.id.btn_feasibility);


        submit=(Button)findViewById(R.id.submit);

        edt_manual_fes=(EditText)findViewById(R.id.edt_manual_fes);
    }

    //.....................home location........................//
    public void getHomeLocationNetwork()
    {

        Location nwLocation = appLocationService
                .getLocation(LocationManager.NETWORK_PROVIDER);

        if (nwLocation != null) {
            double latitude = nwLocation.getLatitude();
            double longitude = nwLocation.getLongitude();
            tv_lat_home.setText("");
            tv_lat_home.setText(String.valueOf(latitude));
            tv_long_home.setText("");
            tv_long_home.setText(String.valueOf(longitude));
           /* Toast.makeText(
                    getApplicationContext(),
                    "Mobile Location (NW): \nLatitude: " + latitude
                            + "\nLongitude: " + longitude,
                    Toast.LENGTH_LONG).show();*/
            Log.e("Location", "Mobile Location (NW): \nLatitude: " + latitude
                    + "\nLongitude: " + longitude);
        } else {
            showSettingsAlert("NETWORK");
        }

    }

    public void getHomeLocationGPS()
    {
        Location gpsLocation = appLocationService
                .getLocation(LocationManager.GPS_PROVIDER);

        if (gpsLocation != null) {
            double latitude = gpsLocation.getLatitude();
            double longitude = gpsLocation.getLongitude();
            tv_lat_home.setText("");
            tv_lat_home.setText(String.valueOf(latitude));
            tv_long_home.setText("");
            tv_long_home.setText(String.valueOf(longitude));
          /*  Toast.makeText(
                    getApplicationContext(),
                    "Mobile Location (GPS): \nLatitude: " + latitude
                            + "\nLongitude: " + longitude,
                    Toast.LENGTH_LONG).show();
*/
        } else {
            showSettingsAlert("GPS");
        }
    }

    //.....................home location........................//
    public void getPoleLocationNetwork()
    {


        Location nwLocation = appLocationService
                .getLocation(LocationManager.NETWORK_PROVIDER);

        if (nwLocation != null) {
            double latitude = nwLocation.getLatitude();
            double longitude = nwLocation.getLongitude();
            tv_lat_pole.setText("");
            tv_lat_pole.setText(String.valueOf(latitude));
            tv_long_pole.setText("");
            tv_long_pole.setText(String.valueOf(longitude));
            /*Toast.makeText(
                    getApplicationContext(),
                    "Mobile Location (NW): \nLatitude: " + latitude
                            + "\nLongitude: " + longitude,
                    Toast.LENGTH_LONG).show();*/
            Log.e("Location", "Mobile Location (NW): \nLatitude: " + latitude
                    + "\nLongitude: " + longitude);
        } else {
            showSettingsAlert("NETWORK");
        }

    }

    public void getPoleLocationGPS()
    {
        Location gpsLocation = appLocationService
                .getLocation(LocationManager.GPS_PROVIDER);

        if (gpsLocation != null) {
            double latitude = gpsLocation.getLatitude();
            double longitude = gpsLocation.getLongitude();
            tv_lat_pole.setText("");
            tv_lat_pole.setText(String.valueOf(latitude));
            tv_long_pole.setText("");
            tv_long_pole.setText(String.valueOf(longitude));
           /* Toast.makeText(
                    getApplicationContext(),
                    "Mobile Location (GPS): \nLatitude: " + latitude
                            + "\nLongitude: " + longitude,
                    Toast.LENGTH_LONG).show();
*/
        } else {
            showSettingsAlert("GPS");
        }
    }

    public void showSettingsAlert(String provider) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(
                Feasibility.this);

        alertDialog.setTitle(provider + " SETTINGS");

        alertDialog
                .setMessage(provider + " is not enabled! Want to go to settings menu?");

        alertDialog.setPositiveButton("Settings",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(
                                Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        Feasibility.this.startActivity(intent);
                    }
                });

        alertDialog.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        alertDialog.show();
    }

    public class SendFeasibility extends AsyncTask<String, String,String>
    {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd=new ProgressDialog(Feasibility.this);
            pd.setMessage("record sending");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... params) {

            ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
            nameValuePairs.add(new BasicNameValuePair("tag","set_feasibility"));
            nameValuePairs.add(new BasicNameValuePair("ticket_no",str_ticket_no));
            nameValuePairs.add(new BasicNameValuePair("home_lat",String.valueOf(home_lat)));
            nameValuePairs.add(new BasicNameValuePair("home_long",String.valueOf(home_long)));
            nameValuePairs.add(new BasicNameValuePair("pole_lat",String.valueOf(pole_lat)));
            nameValuePairs.add(new BasicNameValuePair("pole_long",String.valueOf(pole_long)));

            nameValuePairs.add(new BasicNameValuePair("tranformer_capacity",str_tranformer_capacity));
            nameValuePairs.add(new BasicNameValuePair("tranformer_code",str_tranformer_code));
            nameValuePairs.add(new BasicNameValuePair("pole_no",str_pole_no));
            nameValuePairs.add(new BasicNameValuePair("radio_adjacent_status",DataHolderClass.getInstance().getRadio_adjacent_cons()));
            nameValuePairs.add(new BasicNameValuePair("ncons_no",str_n_cons_no));
            nameValuePairs.add(new BasicNameValuePair("nmru_no",str_n_mru_no));
            nameValuePairs.add(new BasicNameValuePair("radio_wiring_status",DataHolderClass.getInstance().getRadio_wiring_status()));

            nameValuePairs.add(new BasicNameValuePair("feasibility",String.valueOf(value_feasibility)));
            nameValuePairs.add(new BasicNameValuePair("manual_fes",str_manual_fes));
            Log.e("namevaluepair",""+nameValuePairs);
            try
            {
                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost(sessionManager.GET_URL());
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                ResponseHandler<String> responseHandler = new BasicResponseHandler();
                response = httpclient.execute(httppost,responseHandler);
            }
            catch(Exception e)
            {
                network_interrupt=e.getMessage().toString();
                Log.e("log_tag", "Error in http connection "+e.toString());
            }
            return response;
        }


        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.dismiss();
            pd.hide();
            try {
                if(network_interrupt==null) {

                    response = response.trim();
                    Log.e("response",response);
                    if (response.equalsIgnoreCase("1")) {
                        Toast.makeText(getApplicationContext(), "record send successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Feasibility.this, Feasibility_photo.class));
                        finish();

                    } else {
                        ShowAlert();

                    }



                }else{
                    sqLiteMasterTableAdapter.openToRead();
                    sqLiteMasterTableAdapter.openToWrite();
                    sqLiteMasterTableAdapter.insert_feasibility("set_feasibility", str_ticket_no,
                            String.valueOf(home_lat),
                            String.valueOf(home_long),
                            String.valueOf(pole_lat),
                            String.valueOf(pole_long),
                            str_route,
                            value_feasibility,str_manual_fes
                    );
                    sqLiteMasterTableAdapter.close();
                    Toast.makeText(getApplicationContext(),"Record Saved due to internet interruption", Toast.LENGTH_SHORT).show();
                    finish();


                }
            } catch (Exception e) {
                ShowAlert();
            }


        }
    }

    public void ShowAlert() {
        Feasibility.this.runOnUiThread(new Runnable() {
            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(Feasibility.this);
                builder.setTitle("Do you want to...");
                builder.setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        new SendFeasibility().execute();
                    }
                });
                builder.setNegativeButton("Save Record", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int id) {
                        sqLiteMasterTableAdapter.openToRead();
                        sqLiteMasterTableAdapter.openToWrite();
                        sqLiteMasterTableAdapter.insert_feasibility("tag", "str_ticket_no",
                                String.valueOf(home_lat),
                                String.valueOf(home_long),
                                String.valueOf(pole_lat),
                                String.valueOf(pole_long),
                                str_route,
                                value_feasibility,str_manual_fes
                        );
                        sqLiteMasterTableAdapter.close();
                        Toast.makeText(getApplicationContext(),"record saved", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
    }







}