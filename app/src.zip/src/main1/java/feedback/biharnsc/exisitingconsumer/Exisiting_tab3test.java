package feedback.mpnsc.exisitingconsumer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;

import feedback.mpnsc.ConnectionDetector;
import feedback.mpnsc.DataHolderClass;
import feedback.mpnsc.MultipleTicketManager;
import feedback.mpnsc.Options;
import feedback.mpnsc.R;
import feedback.mpnsc.SQLiteAdapter;
import feedback.mpnsc.SQLiteMasterTableAdapter;
import feedback.mpnsc.SessionManager;

/**
 * Created by swatiG on 02-07-2015.
 */
public class Exisiting_tab3test extends Activity {


    EditText connect_load;
    Spinner tariff_spinner,tariff_spinner_subcat,tariff_spinner_subcat_a;
    TextView load_unit,TVTicketnum;
    String str_supply_type, str_supply_level, str_load_unit, str_metering_side, str_trans_ownership, str_trans_capacity,
            str_tariff_cat,str_tariff_cat1,str_bill_demand,str_scheme,str_connection,str_connect_load,str_other,str_tariff_subcat,str_tariff_subcat_a;

    /** Called when the activity is first created. */
    Button submit;

    int int_tariff_cat,int_connection;
    ConnectionDetector connectionDetector;

    SQLiteMasterTableAdapter sqLiteMasterTableAdapter;
    MultipleTicketManager sqLiteMultipleTicketList;

    String response;
    SessionManager sessionManager;

    SQLiteAdapter sqlAdapter;

    ArrayList<String> tariffArraycode, tariffArrayname;

    ArrayAdapter<String> tariffAdapter;

    Cursor tarifftablecursor;
    String str_tariff;

    int int_tariff;
    int count1 = 0, count = 0, count2;
    boolean check = true;
    String str_tariff_nitin;

    TextView tv_subcat,tv_subcat_a;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab3);
        connectionDetector=new ConnectionDetector(this);
        sessionManager=new SessionManager(Exisiting_tab3test.this);
        sqLiteMasterTableAdapter= new SQLiteMasterTableAdapter(Exisiting_tab3test.this);
        sqLiteMultipleTicketList=new MultipleTicketManager(Exisiting_tab3test.this);
        callView();
        TVTicketnum.setText(DataHolderClass.getInstance().get_new_meter_ticket_no());
        //connect_load.setText(DataHolderExisting.getInstance().getLoadreq());
        str_tariff_cat = DataHolderExisting.getInstance().getLoadcategory();

        tv_subcat = (TextView) findViewById(R.id.textView_subcat);
        tv_subcat.setVisibility(View.GONE);
        tv_subcat_a = (TextView) findViewById(R.id.textView_subcat_a);
        tv_subcat_a.setVisibility(View.GONE);


        tariff_spinner_subcat = (Spinner) findViewById(R.id.spinner_subcat);
        tariff_spinner_subcat.setVisibility(View.GONE);
       // tariff_spinner_subcat.setVisibility(View.GONE);

        tariff_spinner_subcat_a = (Spinner) findViewById(R.id.spinner_subcat_a);
        tariff_spinner_subcat_a.setVisibility(View.GONE);
        //tariff_spinner_subcat_a.setVisibility(View.GONE);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //getValue();
                getValidate();
                //tariff_code = tariff_spinner.getSelectedItem().toString();
               /* str_load_unit = load_unit.getText().toString();
                str_connect_load = connect_load.getText().toString();
                //DataHolderClass.getInstance().setStr_spinner_address_proof(str_spinner_address);

                if (connectionDetector.isConnectingToInternet()) {
                    //send data
                    new SendToServer().execute();
                } else {
                    Toast.makeText(getApplicationContext(),"Data Not sending to server",Toast.LENGTH_SHORT).show();
                }*/


            }
        });


        tariffArraycode = new ArrayList<String>();
        tariffArrayname = new ArrayList<String>();

        new TARIFFTABLEMANAGER(Exisiting_tab3test.this).execute();
       /* tariff_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
           @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // TODO Auto-generated method stub
                //  Log.e("from","spinner1");
                if (count > 1) {

                    str_tariff_cat = tariffArraycode.get(position).toString();
                    str_tariff_nitin=str_tariff_cat;
                   // DataHolderClass.getInstance().set_tariff_cat(str_tariff_cat);
                     Log.e("str_tariff_cat:",str_tariff_cat);
                    System.out.println("str_tariff_cat:"+ str_tariff_cat);
//                  Toast.makeText(getApplicationContext(),""+position,Toast.LENGTH_LONG).show();
                    if (position > 0) {
                        // new SUBDIVISIONTABLEMANAGER(Existing_tab1.this).execute();
                    } else {

                    }
                }
                count++;
                //  Log.e("count",""+count);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });*/


        tariff_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 1) {

                    tariff_spinner_subcat = (Spinner) findViewById(R.id.spinner_subcat);
                    tariff_spinner_subcat.setVisibility(View.VISIBLE);
                    tv_subcat.setVisibility(View.VISIBLE);
                    str_tariff_cat = tariff_spinner_subcat.getSelectedItem().toString();
                    DataHolderClass.getInstance().set_connect_load(str_tariff_cat);
                    tariff_spinner_subcat_a.setVisibility(View.GONE);
                    tv_subcat_a.setVisibility(View.GONE);
                } else if (position == 2 ) {
                    tariff_spinner_subcat_a = (Spinner) findViewById(R.id.spinner_subcat_a);
                    tariff_spinner_subcat_a.setVisibility(View.VISIBLE);
                    tv_subcat_a.setVisibility(View.VISIBLE);
                    str_tariff_cat = tariff_spinner_subcat_a.getSelectedItem().toString();
                    DataHolderClass.getInstance().set_connect_load(str_tariff_cat);
                    tariff_spinner_subcat.setVisibility(View.GONE);
                    tv_subcat.setVisibility(View.GONE);
                } else if (position == 3 ) {
                    tariff_spinner_subcat = (Spinner) findViewById(R.id.spinner_subcat);
                    tariff_spinner_subcat.setVisibility(View.VISIBLE);
                    tv_subcat.setVisibility(View.VISIBLE);
                    str_tariff_cat = tariff_spinner_subcat.getSelectedItem().toString();
                    DataHolderClass.getInstance().set_connect_load(str_tariff_cat);
                    tariff_spinner_subcat_a.setVisibility(View.GONE);
                    tv_subcat_a.setVisibility(View.GONE);
                } else {

                    tariff_spinner_subcat.setVisibility(View.GONE);
                    tariff_spinner_subcat_a.setVisibility(View.GONE);
                    tv_subcat.setVisibility(View.GONE);
                    tv_subcat_a.setVisibility(View.GONE);
                    //tariff_spinner_subcat.setVisibility(View.INVISIBLE);

                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



    }

    public void callView()
    {
        TVTicketnum=(TextView)findViewById(R.id.textViewTicketValue);
        load_unit=(TextView)findViewById(R.id.spinner13);
        tariff_spinner=(Spinner)findViewById(R.id.spinner17);
        //connect_load=(EditText)findViewById(R.id.spinner10);

        /*tariff_spinner_subcat = (Spinner) findViewById(R.id.spinner_subcat);
        tariff_spinner_subcat.setVisibility(View.INVISIBLE);
        tariff_spinner_subcat.setVisibility(View.GONE);

        tariff_spinner_subcat_a = (Spinner) findViewById(R.id.spinner_subcat_a);
        tariff_spinner_subcat_a.setVisibility(View.INVISIBLE);
        tariff_spinner_subcat_a.setVisibility(View.GONE);*/

        submit=(Button)findViewById(R.id.submit);
           //getValue();
    }


    public void getValue() {
        str_load_unit = load_unit.getText().toString();
        //str_connect_load = connect_load.getText().toString().trim();
        str_tariff = tariff_spinner.getSelectedItem().toString();
        str_tariff_subcat = tariff_spinner_subcat.getSelectedItem().toString();
        str_tariff_subcat_a = tariff_spinner_subcat_a.getSelectedItem().toString();


        DataHolderClass dataHolderClass = DataHolderClass.getInstance();


        //dataHolderClass.set_tariff_cat(str_tariff_cat);

        dataHolderClass.set_connect_load(str_connect_load);


        Log.e("tab3", str_tariff_cat +  str_connect_load);


    }

    public void getValidate() {
        //str_connect_load = connect_load.getText().toString().trim();
        int_tariff_cat = tariff_spinner.getSelectedItemPosition();

        // Log.e("postion1", String.valueOf(int_connection));
        Log.e("postion2", String.valueOf(int_tariff_cat));

           getValue();

        //if (str_connect_load.equals("") || (int_tariff_cat == 0)) {
        if ((int_tariff_cat == 0)) {
            //connect_load.setBackgroundColor(Color.YELLOW);

            tariff_spinner.setBackgroundColor(Color.YELLOW);

            Toast.makeText(getApplicationContext(), "Enter the mandatory fields LOAD PROFILE", Toast.LENGTH_SHORT).show();

        } else {
            if (connectionDetector.isConnectingToInternet()) {
                //send data
                new SendToServer().execute();
            } else {
                Toast.makeText(getApplicationContext(),"Data Not sending to server",Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        ShowAlertonBack();
    }
    public void ShowAlertonBack(){
        Exisiting_tab3test.this.runOnUiThread(new Runnable() {
            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(Exisiting_tab3test.this);
                builder.setTitle("Are you sure to go back:");
                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        startActivity(new Intent(Exisiting_tab3test.this, ExistingConsumer_Search.class));
                        finish();
                    }
                });
                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
    }


    public class SendToServer extends AsyncTask<String, String,String>
    {    String network_interrupt=null;
        ProgressDialog pd;
        @Override
        protected void onPreExecute()
        {
            // TODO Auto-generated method stub
            super.onPreExecute();
            pd=new ProgressDialog(Exisiting_tab3test.this);
            pd.setMessage("record sending");
            pd.setCancelable(false);
            pd.show();
        }
        @Override
        protected String doInBackground(String... params) {

            ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
            nameValuePairs.add(new BasicNameValuePair("tag","update_consumer"));

            nameValuePairs.add(new BasicNameValuePair("ticket",DataHolderClass.getInstance().get_new_meter_ticket_no()));
            nameValuePairs.add(new BasicNameValuePair("division", DataHolderClass.getInstance().get_division()));
            nameValuePairs.add(new BasicNameValuePair("subdivision", DataHolderClass.getInstance().get_subdivion()));
            nameValuePairs.add(new BasicNameValuePair("section", DataHolderClass.getInstance().get_section()));

            nameValuePairs.add(new BasicNameValuePair("title", DataHolderClass.getInstance().get_title()));
            nameValuePairs.add(new BasicNameValuePair("first_name", DataHolderClass.getInstance().get_name()));
            nameValuePairs.add(new BasicNameValuePair("middle_name", DataHolderClass.getInstance().getStr_middle_name()));
            nameValuePairs.add(new BasicNameValuePair("last_name", DataHolderClass.getInstance().getStr_last_name()));
            nameValuePairs.add(new BasicNameValuePair("father_name", DataHolderClass.getInstance().get_father_name()));

            nameValuePairs.add(new BasicNameValuePair("building_no", DataHolderClass.getInstance().get_bulding_no()));
            nameValuePairs.add(new BasicNameValuePair("house_flatno", DataHolderClass.getInstance().getHouse_flatno()));
            nameValuePairs.add(new BasicNameValuePair("housename", DataHolderClass.getInstance().getHousename()));
            nameValuePairs.add(new BasicNameValuePair("khatano", DataHolderClass.getInstance().getKhata_no()));
            nameValuePairs.add(new BasicNameValuePair("ward_no", DataHolderClass.getInstance().getWard_no()));
            nameValuePairs.add(new BasicNameValuePair("street", DataHolderClass.getInstance().get_street()));
            nameValuePairs.add(new BasicNameValuePair("block", DataHolderClass.getInstance().get_block()));
            nameValuePairs.add(new BasicNameValuePair("panchayat", DataHolderClass.getInstance().get_gp()));
            nameValuePairs.add(new BasicNameValuePair("address", DataHolderClass.getInstance().getStr_adres1()));
            nameValuePairs.add(new BasicNameValuePair("pin_no", DataHolderClass.getInstance().get_pin_no()));
            nameValuePairs.add(new BasicNameValuePair("landmark", DataHolderClass.getInstance().getLandmark()));

            nameValuePairs.add(new BasicNameValuePair("village", DataHolderClass.getInstance().get_city()));
            nameValuePairs.add(new BasicNameValuePair("district", DataHolderClass.getInstance().get_district()));
            nameValuePairs.add(new BasicNameValuePair("telephone", DataHolderClass.getInstance().get_landline()));
            nameValuePairs.add(new BasicNameValuePair("mobile",DataHolderClass.getInstance().get_mobile()));
            nameValuePairs.add(new BasicNameValuePair("email",DataHolderClass.getInstance().get_email()));
            nameValuePairs.add(new BasicNameValuePair("category",str_tariff_nitin));
            nameValuePairs.add(new BasicNameValuePair("get_connect_load",DataHolderClass.getInstance().get_connect_load()));

            Log.e("namevaluepair",""+nameValuePairs);
            try
            {
                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost(sessionManager.GET_URL());
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                ResponseHandler<String> responseHandler = new BasicResponseHandler();
                response = httpclient.execute(httppost,responseHandler);
            }
            catch(Exception e)
            {
                network_interrupt=e.getMessage().toString();
                Log.e("log_tag", "Error in http connection "+e.toString());
            }
            return response;
        }
        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.dismiss();
            pd.hide();
            try {
                if(network_interrupt==null) {

                    response = response.trim();
                    Log.e("response",response);
                    if (response.equalsIgnoreCase("1")) {
                        Toast.makeText(getApplicationContext(), "record send successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Exisiting_tab3test.this, Options.class));
                        finish();
                    } else {
                        ShowAlert();

                    }



                }else{
                    /*sqLiteMasterTableAdapter.openToRead();
                    sqLiteMasterTableAdapter.openToWrite();
                    sqLiteMasterTableAdapter.insert_feasibility("set_feasibility", str_ticket_no,
                            String.valueOf(home_lat),
                            String.valueOf(home_long),
                            String.valueOf(pole_lat),
                            String.valueOf(pole_long),
                            str_route,
                            value_feasibility,str_manual_fes
                    );
                    sqLiteMasterTableAdapter.close();*/
                    Toast.makeText(getApplicationContext(),"Record not send due to internet interruption", Toast.LENGTH_SHORT).show();
                    finish();


                }
            } catch (Exception e) {
                ShowAlert();
            }


        }


        public void ShowAlert() {
            Exisiting_tab3test.this.runOnUiThread(new Runnable() {
                public void run() {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Exisiting_tab3test.this);
                    builder.setTitle("Do you want to...");
                    builder.setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            new Exisiting_tab3test.SendToServer().execute();
                        }
                    });
                    builder.setNegativeButton("Save Record", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Toast.makeText(getApplicationContext(),"Record Saved",Toast.LENGTH_SHORT).show();
                           /* sqLiteMasterTableAdapter.openToRead();
                            sqLiteMasterTableAdapter.openToWrite();
                            sqLiteMasterTableAdapter.mastersubdivision_insert_new
                                    (DataHolderClass.getInstance().get_division(),
                                            DataHolderClass.getInstance().get_subdivion(),
                                            DataHolderClass.getInstance().get_section(),
                                            "",
                                            DataHolderClass.getInstance().get_name(),
                                            DataHolderClass.getInstance().get_father_name(),
                                            DataHolderClass.getInstance().get_name_org_corp(),
                                            DataHolderClass.getInstance().get_type_org(),
                                            DataHolderClass.getInstance().get_name_org(),
                                            DataHolderClass.getInstance().get_block(),//signat_name
                                            DataHolderClass.getInstance().get_bulding_no(),
                                            DataHolderClass.getInstance().get_city(),
                                            DataHolderClass.getInstance().get_district(),
                                            DataHolderClass.getInstance().get_gp(),
                                            DataHolderClass.getInstance().get_house_no(),//plot
                                            DataHolderClass.getInstance().get_street(),
                                            DataHolderClass.getInstance().get_tehsil(),
                                            DataHolderClass.getInstance().get_village(),
                                            DataHolderClass.getInstance().get_block1(),
                                            DataHolderClass.getInstance().get_city1(),
                                            DataHolderClass.getInstance().get_district1(),
                                            DataHolderClass.getInstance().get_gp1(),
                                            DataHolderClass.getInstance().get_house_no1(),
                                            DataHolderClass.getInstance().get_street1(),
                                            DataHolderClass.getInstance().get_tehsil1(),
                                            DataHolderClass.getInstance().get_village1(),
                                            DataHolderClass.getInstance().get_bulding_no1(),
                                            DataHolderClass.getInstance().get_mobile(),
                                            DataHolderClass.getInstance().get_email1(),
                                            DataHolderClass.getInstance().get_landline1(),
                                            DataHolderClass.getInstance().get_designation(),
                                            DataHolderClass.getInstance().get_connect_load(),
                                            DataHolderClass.getInstance().get_tariff_cat(),
                                            "0.0",
                                            "0.0",
                                            "0.0",
                                            "0.0",
                                            image, meterimageName+","+DataHolderClass.getInstance().get_person_available(),
                                            DataHolderClass.getInstance().get_pan_no(),
                                            DataHolderClass.getInstance().get_pin_no(),
                                            DataHolderClass.getInstance().get_pin_no1());*/

                            Toast.makeText(getApplicationContext(),"record saved",Toast.LENGTH_LONG).show();
                            finish();
                        }
                    });
                    AlertDialog alert = builder.create();
                    alert.show();
                }
            });
        }
    }
    public void show_ticket(String ticketNumber) {
        Exisiting_tab3test.this.runOnUiThread(new Runnable() {
            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(Exisiting_tab3test.this);
                builder.setTitle("Ticket Number:");
                builder.setMessage(response);
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
    }


    public class TARIFFTABLEMANAGER extends AsyncTask<String, String, String> {
        ProgressDialog pd;
        Context _context;

        TARIFFTABLEMANAGER(Context ctx) {
            _context = ctx;
        }

        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            // ShowAlertagain();
            super.onPreExecute();
            pd = new ProgressDialog(Exisiting_tab3test.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            sqlAdapter = new SQLiteAdapter(Exisiting_tab3test.this);
            try {
                sqlAdapter.openToRead();
                sqlAdapter.openToWrite();
                tarifftablecursor = sqlAdapter.mastertariffcursorAll();
                if (tarifftablecursor != null && tarifftablecursor.moveToFirst()) {
                    tariffArraycode.add("---select---");
                    tariffArrayname.add("---select---");
                    do {
                        String scheme = tarifftablecursor.getString(2);
                        String schemename = tarifftablecursor.getString(3);
                        tariffArraycode.add(scheme);
                        tariffArrayname.add(schemename);
                    } while (tarifftablecursor.moveToNext());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            pd.hide();
            pd.dismiss();
            try {
                tariffAdapter = new ArrayAdapter<String>(Exisiting_tab3test.this, android.R.layout.simple_spinner_item, tariffArrayname);
                tariffAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                tariff_spinner.setAdapter(tariffAdapter);
                sqlAdapter.close();
                if (check) {
                    //  Log.e("str_division_code", "" + str_division_code);
                    int position = tariffArraycode.indexOf(str_tariff_cat);
                    // Log.e("position", "" + position);
                    tariff_spinner.setSelection(position);

                    // new SUBDIVISIONTABLEMANAGER(Existing_tab1.this).execute();
                }


            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


}